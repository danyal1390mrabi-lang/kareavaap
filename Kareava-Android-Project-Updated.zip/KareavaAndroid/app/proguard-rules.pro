# Kareava WebView app: no custom ProGuard rules required.
